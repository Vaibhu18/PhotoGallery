function goToDown(){
   
  
    window.scrollTo(0,document.body.scrollHeight);
    

}